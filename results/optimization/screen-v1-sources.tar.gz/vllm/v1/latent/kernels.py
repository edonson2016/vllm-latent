# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Captured token/latent input selection and optional masked expectation kernels."""

import torch

from vllm.triton_utils import tl, triton


@triton.jit
def _input(
    ids, weight, history, masks, indices, output, D: tl.constexpr, BLOCK: tl.constexpr
):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK)
    index = tl.load(indices + row)
    latent = tl.load(masks + tl.maximum(index, 0)) & (index >= 0)
    if latent:
        values = tl.load(history + index * D + cols, cols < D, 0)
    else:
        token = tl.load(ids + row)
        values = tl.load(weight + token * D + cols, cols < D, 0)
    tl.store(output + row * D + cols, values, cols < D)


@torch.library.custom_op("vllm::latent_input", mutates_args=())
def latent_input(
    ids: torch.Tensor,
    weight: torch.Tensor,
    history: torch.Tensor,
    masks: torch.Tensor,
    indices: torch.Tensor,
) -> torch.Tensor:
    output = torch.empty(
        (ids.numel(), weight.shape[1]), device=weight.device, dtype=weight.dtype
    )
    _input[(ids.numel(),)](
        ids,
        weight,
        history,
        masks,
        indices,
        output,
        weight.shape[1],
        triton.next_power_of_2(weight.shape[1]),
    )
    return output


@latent_input.register_fake
def _fake_input(ids, weight, history, masks, indices):
    return weight.new_empty((ids.numel(), weight.shape[1]))


class LatentEmbedding(torch.nn.Module):
    def __init__(self, original, history, masks, indices):
        super().__init__()
        self.weight = original.weight
        self.register_buffer("history", history, persistent=False)
        self.register_buffer("masks", masks, persistent=False)
        self.register_buffer("indices", indices, persistent=False)

    def forward(self, ids):
        return latent_input(ids, self.weight, self.history, self.masks, self.indices)


@triton.jit
def _commit(
    result,
    latent,
    state,
    metadata,
    history,
    masks,
    states,
    sampled,
    D: tl.constexpr,
    STEPS: tl.constexpr,
    BLOCK: tl.constexpr,
):
    row = tl.program_id(0)
    slot = tl.load(metadata + row * 4 + 1)
    if slot >= 0:
        source = tl.load(metadata + row * 4)
        step = tl.load(metadata + row * 4 + 2)
        index = slot * STEPS + step
        cols = tl.arange(0, BLOCK)
        value = tl.load(result + row * D + cols, cols < D, 0)
        tl.store(history + index * D + cols, value, cols < D)
        mask = tl.load(latent + row)
        tl.store(masks + index, mask)
        if mask:
            tl.store(sampled + source, 0)
        regs = tl.arange(0, 8)
        values = tl.load(state + row * 8 + regs)
        tl.store(states + slot * 8 + regs, values)


def commit(result, latent, state, metadata, history, masks, states, sampled):
    _commit[(result.shape[0],)](
        result,
        latent,
        state,
        metadata,
        history,
        masks,
        states,
        sampled,
        result.shape[1],
        history.shape[1],
        triton.next_power_of_2(result.shape[1]),
    )


@triton.jit
def _expect_parts(
    prob,
    embedding,
    gate,
    parts,
    V: tl.constexpr,
    D: tl.constexpr,
    CHUNKS: tl.constexpr,
    BV: tl.constexpr,
    BD: tl.constexpr,
):
    row, vc, dc = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    cols = dc * BD + tl.arange(0, BD)
    value = tl.full((BD,), 0, tl.float32)
    if tl.load(gate + row):
        vocab = vc * BV + tl.arange(0, BV)
        p = tl.load(prob + row * V + vocab, vocab < V, 0)
        e = tl.load(
            embedding + vocab[:, None] * D + cols[None, :],
            (vocab[:, None] < V) & (cols[None, :] < D),
            0,
        )
        # Match EXPECT's BF16 probability rounding before FP32 accumulation.
        p = p.to(e.dtype).to(tl.float32)
        value = tl.sum(p[:, None] * e.to(tl.float32), axis=0)
    tl.store(parts + (row * CHUNKS + vc) * D + cols, value, cols < D)


@triton.jit
def _expect_reduce(
    parts,
    output,
    D: tl.constexpr,
    CHUNKS: tl.constexpr,
    BC: tl.constexpr,
    BD: tl.constexpr,
):
    row, dc = tl.program_id(0), tl.program_id(1)
    chunks, cols = tl.arange(0, BC), dc * BD + tl.arange(0, BD)
    values = tl.load(
        parts + (row * CHUNKS + chunks[:, None]) * D + cols[None, :],
        (chunks[:, None] < CHUNKS) & (cols[None, :] < D),
        0,
    )
    tl.store(output + row * D + cols, tl.sum(values, axis=0), cols < D)


def masked_expect(prob, embedding, gate=None):
    batch, vocab = prob.shape
    width = embedding.shape[1]
    chunks = triton.cdiv(vocab, 512)
    if gate is None:
        gate = torch.ones(batch, device=prob.device, dtype=torch.bool)
    parts = torch.empty((batch, chunks, width), device=prob.device)
    output = torch.empty((batch, width), device=prob.device, dtype=embedding.dtype)
    _expect_parts[(batch, chunks, triton.cdiv(width, 32))](
        prob, embedding, gate, parts, vocab, width, chunks, 512, 32
    )
    _expect_reduce[(batch, triton.cdiv(width, 32))](
        parts, output, width, chunks, triton.next_power_of_2(chunks), 32
    )
    return output
