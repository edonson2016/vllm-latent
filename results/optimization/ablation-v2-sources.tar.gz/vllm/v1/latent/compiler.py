# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Static dependency analysis and common-subexpression sharing at admission."""

import copy

import torch


def dependencies(program):
    live = {program.output, program.latent, *program.updates.values()}
    kept = []
    for dst, op, args in reversed(program.ops):
        if dst not in live:
            continue
        kept.append((dst, op, args))
        if op != "CONST":
            live.update(args[:-1] if op in {"PROJECT", "TOPK_EXPECT"} else args)
    return list(reversed(kept)), live


def optimize(program):
    result = copy.copy(program)
    result.ops, result.live = dependencies(program)
    nodes = {dst: (dst, op, args) for dst, op, args in result.ops}
    ordered = []
    seen = set()

    def emit(name):
        if name in seen or name not in nodes:
            return
        dst, op, args = nodes[name]
        if op != "CONST":
            for arg in args[:-1] if op in {"PROJECT", "TOPK_EXPECT"} else args:
                emit(arg)
        seen.add(name)
        ordered.append((dst, op, args))

    for name in [result.latent, result.output, *result.updates.values()]:
        emit(name)
    result.ops = ordered
    return result


def inactive(program, step):
    """Prove a stateless transition inactive using only scheduler position.

    Unknown device values propagate conservatively. This never reads a tensor
    or substitutes a host decision for a data-dependent predicate.
    """
    if program.updates:
        return False
    values = {"step": step}
    for dst, op, args in program.ops:
        x = values.get(args[0]) if args else None
        y = values.get(args[1]) if len(args) > 1 else None
        if op == "CONST":
            values[dst] = args[0]
        elif op == "AND" and (x is False or y is False):
            values[dst] = False
        elif op == "OR" and (x is True or y is True):
            values[dst] = True
        elif x is not None and y is not None:
            if op == "LT":
                values[dst] = x < y
            elif op == "GT":
                values[dst] = x > y
            elif op == "EQ":
                values[dst] = x == y
            elif op == "AND":
                values[dst] = x and y
            elif op == "OR":
                values[dst] = x or y
    return values.get(program.latent) is False


def active_without_logits(program, step):
    if program.fallback != "zero" or {"logits", "token"} & dependencies(program)[1]:
        return False
    # Conservative proof for the common fixed hidden-prefix contract only.
    nodes = {dst: (op, args) for dst, op, args in program.ops}
    op, args = nodes.get(program.latent, (None, []))
    if op == "CONST":
        return args == [True]
    if op == "LT" and args[0] == "step":
        limit_op, limit_args = nodes.get(args[1], (None, []))
        return limit_op == "CONST" and step < limit_args[0]
    return False


class SharedProgram:
    """Evaluate compatible requests together, sharing identical tensor nodes."""

    def __init__(self, programs, share=True):
        self.programs = programs
        self.share = share
        self.live = set().union(*(dependencies(p)[1] for p in programs))

    def __call__(self, logits, hidden, token, step, state, embedding, ids):
        cache = {} if self.share else None
        result, mask, next_state = (
            token,
            torch.zeros_like(step, dtype=torch.bool),
            state,
        )
        for i, program in enumerate(self.programs):
            output, latent, updated = program(
                logits, hidden, token, step, state, embedding, cache=cache
            )
            selected = ids == i
            result = torch.where(selected, output, result)
            mask = torch.where(selected, latent, mask)
            next_state = torch.where(selected, updated, next_state)
        return result, mask, next_state


def fuse_expectations(program):
    result = copy.copy(program)
    sources = {dst: args[0] for dst, op, args in program.ops if op == "SOFTMAX"}
    result.ops = [
        (dst, "SOFT_EXPECT", [sources[args[0]]])
        if op == "EXPECT" and args[0] in sources
        else (dst, op, args)
        for dst, op, args in program.ops
    ]
    result.fused_expect = True
    return optimize(result)
